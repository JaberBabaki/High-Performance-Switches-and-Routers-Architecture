package com.ario.original2_dranges.model;

/**
 * Created by jaber babaki on 7/21/2016.
 */
public class TernaryModel {

  private String ternary;
  private String rule;

  public void setRule(String rule) {
    this.rule = rule;
  }
  public void setTernary(String ternary) {
    this.ternary = ternary;
  }
  public String getRule() {
    return rule;
  }
  public String getTernary() {
    return ternary;
  }
}
