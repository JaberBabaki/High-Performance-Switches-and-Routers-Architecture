package com.ario.original2_dranges.model;

/**
 * Created by jaberALU on 31/12/2017.
 */


public class CodeWordModel {
  public String[] codeWord = new String[]{"0","0","0","0","0","0","0"};
  public String getER() {
    return ER;
  }
  private String ER="";
  public void setER(String ER) {
    this.ER = ER;
  }
}

