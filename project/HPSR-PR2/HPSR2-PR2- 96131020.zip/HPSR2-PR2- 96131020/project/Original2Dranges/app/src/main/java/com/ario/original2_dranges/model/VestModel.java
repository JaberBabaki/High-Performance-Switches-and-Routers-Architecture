package com.ario.original2_dranges.model;

/**
 * Created by jaberALU on 31/12/2017.
 */


public class VestModel {

  private String rule ="";
  private String numberER ="";

  public String getRule() {
    return rule;
  }
  public void setRule(String rule) {
    this.rule = rule;
  }
  public void setNumberER(String numberER) {
    this.numberER = numberER;
  }
  public String getNumberER() {
    return numberER;
  }

}

